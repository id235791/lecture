CREATE TABLE DBMS_USER(
	name VARCHAR2(30),
	birth VARCHAR2(30),
	id VARCHAR2(30) PRIMARY KEY,
	pw VARCHAR2(30),
	address VARCHAR2(1000),
	phone VARCHAR2(30),
	email VARCHAR2(30),
	account VARCHAR2(50)
);
SELECT * FROM dbms_user;
DROP TABLE dbms_user;