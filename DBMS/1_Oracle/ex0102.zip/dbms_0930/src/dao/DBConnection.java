package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnection {
	static Connection conn = null;
	static String driver = "oracle.jdbc.driver.OracleDriver";
	static String url = "jdbc:oracle:thin:@localhost:1521:xe";
	static String user = "hr";
	static String password = "hr";

	public DBConnection() {

	}

	public static Connection getConnection() {
		if (conn == null) {
			try {
				Class.forName(driver);
				System.out.println("jdbc driver �ε� ����");
				conn = DriverManager.getConnection(url, user, password);
				System.out.println("����Ŭ ���� ����");
			} catch (ClassNotFoundException e) {
				System.out.println("jdbc driver �ε� ����");
			} catch (SQLException e) {
				System.out.println("����Ŭ ���� ����");
			}
		}
		return conn;
	}
}
