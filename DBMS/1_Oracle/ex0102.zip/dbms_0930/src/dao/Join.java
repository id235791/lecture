package dao;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.JButton;

public class Join extends JFrame implements ActionListener {

	private JPanel contentPane;
	private JTextField idTextField;
	private JPasswordField pwTextField;
	private JTextField nameTextField;
	private JTextField birthTextField;
	private JTextField phoneTextField;
	private JTextField adrTextField;
	private JTextField accountTextField;
	private JLabel birthExLabel;
	private JLabel bankExLabel;
	private JPanel panel3;
	private JButton finishButton;
	private JTextField emailTextField;
	private JLabel emailLabel;
	private JPanel panel;
	boolean check;
	JLabel checkIdDup;

	public Join() {

	}

	synchronized int joinstart() {
		new JFrame("ȸ������");
		setTitle("ȸ������");
		check = false;
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 428, 460);
		Dimension d = Toolkit.getDefaultToolkit().getScreenSize();

		int xpos = (d.width - getWidth()) / 2;
		int ypos = (d.height - getHeight()) / 2;
		setLocation(xpos, ypos);
		panel = new JPanel();
		contentPane = new JPanel();
		contentPane.setLayout(new BorderLayout(0, 0));
		contentPane.setBorder(new LineBorder(new Color(0, 102, 153), 7));
		setContentPane(contentPane);

		contentPane.add(panel, BorderLayout.CENTER);
		panel.setLayout(null);
		panel.setBackground(new Color(255, 255, 255));

		JLabel idLabel = new JLabel("����� ���̵�");
		idLabel.setHorizontalAlignment(SwingConstants.RIGHT);
		idLabel.setBounds(30, 40, 83, 21);
		panel.add(idLabel);
		checkIdDup = new JLabel();
		checkIdDup.setBounds(125, 20, 200, 18);
		panel.add(checkIdDup);
		JLabel pwLabel = new JLabel("�н�����");
		pwLabel.setHorizontalAlignment(SwingConstants.RIGHT);
		pwLabel.setBounds(30, 80, 83, 18);
		panel.add(pwLabel);

		JLabel nameLabel = new JLabel("�̸�");
		nameLabel.setHorizontalAlignment(SwingConstants.RIGHT);
		nameLabel.setBounds(30, 120, 83, 21);
		panel.add(nameLabel);

		JLabel birthLabel = new JLabel("�������");
		birthLabel.setHorizontalAlignment(SwingConstants.RIGHT);
		birthLabel.setBounds(30, 160, 83, 18);
		panel.add(birthLabel);

		JLabel phoneLabel = new JLabel("�ڵ�����ȣ");
		phoneLabel.setHorizontalAlignment(SwingConstants.RIGHT);
		phoneLabel.setBounds(30, 200, 83, 18);
		panel.add(phoneLabel);

		JLabel adrLabel = new JLabel("�ּ�");
		adrLabel.setHorizontalAlignment(SwingConstants.RIGHT);
		adrLabel.setBounds(30, 240, 83, 18);
		panel.add(adrLabel);

		emailLabel = new JLabel("E-MAIL");
		emailLabel.setHorizontalAlignment(SwingConstants.RIGHT);
		emailLabel.setBounds(30, 280, 83, 21);
		panel.add(emailLabel);

		JLabel bankLabel = new JLabel("���� ���¹�ȣ");
		bankLabel.setHorizontalAlignment(SwingConstants.RIGHT);
		bankLabel.setBounds(30, 320, 83, 18);
		panel.add(bankLabel);

		idTextField = new JTextField();
		idTextField.setBounds(125, 40, 115, 20);
		panel.add(idTextField);
		idTextField.setColumns(10);

		pwTextField = new JPasswordField();
		pwTextField.setColumns(10);
		pwTextField.setBounds(125, 80, 115, 20);
		panel.add(pwTextField);

		nameTextField = new JTextField();
		nameTextField.setColumns(10);
		nameTextField.setBounds(125, 120, 115, 20);
		panel.add(nameTextField);

		birthTextField = new JTextField();
		birthTextField.setColumns(10);
		birthTextField.setBounds(125, 160, 115, 20);
		panel.add(birthTextField);

		phoneTextField = new JTextField();
		phoneTextField.setColumns(10);
		phoneTextField.setBounds(125, 200, 115, 20);
		panel.add(phoneTextField);

		adrTextField = new JTextField();
		adrTextField.setColumns(10);
		adrTextField.setBounds(125, 240, 240, 20);
		panel.add(adrTextField);

		emailTextField = new JTextField();
		emailTextField.setColumns(10);
		emailTextField.setBounds(125, 280, 115, 20);
		panel.add(emailTextField);

		accountTextField = new JTextField();
		accountTextField.setColumns(10);
		accountTextField.setBounds(125, 320, 150, 20);
		panel.add(accountTextField);

		birthExLabel = new JLabel("(YYMMDD)");
		birthExLabel.setHorizontalAlignment(SwingConstants.RIGHT);
		birthExLabel.setBounds(30, 180, 83, 15);
		panel.add(birthExLabel);

		bankExLabel = new JLabel("(���� 00-000-00000)");
		bankExLabel.setBounds(30, 340, 116, 15);
		panel.add(bankExLabel);

		JPanel panel2 = new JPanel();
		panel2.setBounds(251, 33, 102, 41);
		panel2.setBackground(new Color(255, 255, 255));
		panel.add(panel2);
		JButton idCheckButton = new JButton("���̵� �ߺ�Ȯ��");
		idCheckButton.setBackground(new Color(0, 102, 153));
		idCheckButton.setForeground(Color.WHITE);
		panel2.add(idCheckButton);
		idCheckButton.addActionListener(this);

		panel3 = new JPanel();
		panel3.setBounds(251, 371, 116, 41);
		panel3.setBackground(new Color(255, 255, 255));
		panel.add(panel3);

		finishButton = new JButton("���ԿϷ�");
		finishButton.setBackground(new Color(0, 102, 153));
		finishButton.setForeground(Color.WHITE);
		panel3.add(finishButton);
		finishButton.addActionListener(this);

		setVisible(true);
		return 2;
	}

	public synchronized void actionPerformed(ActionEvent e) {
		switch (e.getActionCommand()) {
		case "���ԿϷ�":
			if (!check) {
				JOptionPane.showMessageDialog(null, "���̵� Ȯ���� �ּ���");
				break;
			}
			char[] password = pwTextField.getPassword();
			String pw = "";
			for (int i = 0; i < password.length; i++) {
				pw += password[i];
			}
			try {
				if (new UserDAO().register(nameTextField.getText(), birthTextField.getText(), idTextField.getText(), pw,
						adrTextField.getText(), phoneTextField.getText(), emailTextField.getText(),
						accountTextField.getText())) {
					JOptionPane.showMessageDialog(null, "ȸ�������� �Ϸ�Ǿ����ϴ�.");
					dispose();
					new Login().loginStart();
				}
			} catch (IOException e1) {
			}
			break;
		case "���̵� �ߺ�Ȯ��":
			if (new UserDAO().checkId(idTextField.getText()) == 0) {
				checkIdDup.setText("��� ������ ���̵��Դϴ�.");
				checkIdDup.setForeground(Color.RED);
				check = true;

			} else {
				checkIdDup.setText("�ߺ��Ǵ� ���̵� �ֽ��ϴ�.");
				checkIdDup.setForeground(Color.RED);
				check = false;
			}
			break;
		}
	}
}