package dao;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;

import javax.print.attribute.standard.Chromaticity;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;
import javax.swing.border.MatteBorder;

public class Login extends JFrame implements ActionListener {

	private JPanel contentPane;
	private JTextField idField;
	private JPasswordField passwordField;
	public static int logincheck = 0;
	Join j = new Join();
	public Login() {
	}

	public synchronized int loginStart() {
		new JFrame("�α���");
		setTitle("�α���");
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 360, 288);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setLocationRelativeTo(null);
		setContentPane(contentPane);

		JPanel titlePanel = new JPanel();
		titlePanel.setBorder(new MatteBorder(27, 1, 1, 1, (Color) new Color(51, 102, 153)));
		titlePanel.setBackground(new Color(255, 255, 255));
		contentPane.add(titlePanel, BorderLayout.CENTER);
		titlePanel.setLayout(null);

		JLabel idLabel = new JLabel("���̵�");
		idLabel.setBounds(28, 87, 57, 15);
		titlePanel.add(idLabel);

		JLabel pwLabel = new JLabel("��й�ȣ");
		pwLabel.setBounds(28, 129, 57, 15);
		titlePanel.add(pwLabel);

		idField = new JTextField();
		idField.setBounds(97, 87, 116, 21);
		titlePanel.add(idField);
		idField.setColumns(10);

		passwordField = new JPasswordField();
		passwordField.setBounds(97, 126, 115, 21);
		titlePanel.add(passwordField);

		JPanel loginPanel = new JPanel();
		loginPanel.setBackground(Color.WHITE);
		loginPanel.setBounds(226, 79, 96, 66);
		titlePanel.add(loginPanel);
		loginPanel.setLayout(null);

		JButton loginBtn = new JButton("�α���");
		loginBtn.setForeground(Color.WHITE);
		loginBtn.setBackground(new Color(51, 102, 153));
		loginBtn.setBounds(0, 10, 97, 49);
		loginBtn.addActionListener(this);
		loginBtn.setFocusable(false);
		loginPanel.add(loginBtn);

		JPanel btnPanel = new JPanel();
		btnPanel.setBackground(Color.WHITE);
		btnPanel.setBounds(12, 149, 310, 80);
		titlePanel.add(btnPanel);
		btnPanel.setLayout(null);

		JButton findBtn = new JButton("���̵�/��й�ȣã��");
		findBtn.setForeground(Color.WHITE);
		findBtn.setBackground(new Color(51, 102, 153));
		findBtn.setBounds(0, 22, 164, 35);
		findBtn.addActionListener(this);
		findBtn.setFocusable(false);
		btnPanel.add(findBtn);

		JButton joinBtn = new JButton("ȸ������");
		joinBtn.setBackground(new Color(51, 102, 153));
		joinBtn.setForeground(Color.WHITE);
		joinBtn.setBounds(198, 22, 112, 35);
		joinBtn.setFocusable(false);
		joinBtn.addActionListener(this);
		btnPanel.add(joinBtn);

		JLabel titleLabel = new JLabel("DBMS");
		titleLabel.setBackground(new Color(255, 204, 0));
		titleLabel.setForeground(new Color(0, 0, 0));
		titleLabel.setFont(new Font("Eras Bold ITC", Font.BOLD, 16));
		titleLabel.setHorizontalAlignment(SwingConstants.CENTER);
		titleLabel.setBounds(121, 38, 92, 29);
		titlePanel.add(titleLabel);
		setVisible(true);
		return logincheck;
	}

	@Override
	public synchronized void actionPerformed(ActionEvent e) {
		switch (e.getActionCommand()) {
		case "�α���":
			String id = "";
			char[] pw;
			String password = "";
			id = idField.getText();
			pw = passwordField.getPassword();
			for (int i = 0; i < pw.length; i++) {
				password += pw[i];
			}
			try {
				logincheck = new UserDAO().login(id, password);
				if (logincheck == -1) {
					JOptionPane.showMessageDialog(null, "���̵� �߸� �Է��߽��ϴ�.");
				} else if (logincheck == 0) {
					// ��й�ȣ X
					JOptionPane.showMessageDialog(null, "��й�ȣ�� �߸� �Է��߽��ϴ�.");
				}else {//new Main()}
					dispose();
					JFrame window = new JFrame("�α��� ����");
					window.setBounds(300, 300, 600, 600);
					JPanel panel = new JPanel();
					panel.setBounds(0,0,600,600);
					panel.setLayout(null);
					window.add(panel);
					window.setLayout(null);
					panel.setBackground(Color.WHITE);
					JLabel label = new JLabel("�α��� ����!");
					label.setForeground(Color.MAGENTA);
					label.setBounds(190, 260,400, 40);
					label.setFont(new Font("����",Font.BOLD, 40));
					panel.add(label);
					window.setVisible(true);
//					JOptionPane.showMessageDialog(null, "�α��� ����");
				}
			} catch (IOException e1) {
				;
			}
			break;
		case "ȸ������":
			dispose();
			j.joinstart();
			break;
		}
	}
}