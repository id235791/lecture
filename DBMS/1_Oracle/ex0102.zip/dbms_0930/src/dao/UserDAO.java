package dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import dto.UserDTO;

public class UserDAO {
	Connection conn = null;
	PreparedStatement pstm = null;
	ResultSet rs = null;
	String query = "";

	public UserDAO() {
		conn = DBConnection.getConnection();
	}
	
	// �α��ν� �� ȸ���� �� ��ü
	private static UserDTO u = null;

	// �ٸ� Ŭ�������� ���� �α����� ������ ������ �ޱ� ����
	// getter�� ���
	public static UserDTO getUser() {
		return u;
	}

	// ȸ������ register(name, birth, id, pw, address, phone, email, account);
	boolean register(String name, String birth, String id, String pw, String address, String phone, String email,
			String account) throws IOException {
		int check = 0;
		query = "INSERT INTO DBMS_USER VALUES (?,?,?,?,?,?,?,?)";
		try {
			pstm = conn.prepareStatement(query);
			pstm.setString(1, name);
			pstm.setString(2, birth);
			pstm.setString(3, id);
			pstm.setString(4, pw);
			pstm.setString(5, address);
			pstm.setString(6, phone);
			pstm.setString(7, email);
			pstm.setString(8, account);
			check = pstm.executeUpdate();
		} catch (SQLException e) {
			System.out.println(e);
		} finally {
			try {
				pstm.close();
			} catch (SQLException e) {
				System.out.println(e);
			}
		}
		return check == 1;
	}

	// ���̵� �ߺ��˻�
	int checkId(String id) {
		int num = 0;
		query = "SELECT COUNT(*) FROM DBMS_USER WHERE id=?";
		try {
			pstm = conn.prepareStatement(query);
			pstm.setString(1, id);
			rs = pstm.executeQuery();
			if (rs.next()) {
				num=rs.getInt(1);
			}
		} catch (SQLException e) {
			System.out.println(e);
		} finally {
			try {
				rs.close();
				pstm.close();
			} catch (SQLException e) {
				System.out.println(e);
			}
		}
		return num;
	}

	// �α���
	public int login(String id, String pw) throws IOException {
		int num = 0;
		UserDTO user = null;
		query = "SELECT * FROM DBMS_USER WHERE ID=? AND PW=?";
		try {
			pstm = conn.prepareStatement(query);
			pstm.setString(1, id);
			pstm.setString(2, pw);
			rs = pstm.executeQuery();
			if (rs.next()) {
				user = new UserDTO(rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5),
						rs.getString(6), rs.getString(7), rs.getString(8));
			}
		} catch (SQLException e) {
			System.out.println(e);
		} finally {
			try {
				rs.close();
				pstm.close();
			} catch (SQLException e) {
				System.out.println(e);
			}
		}
		if (user != null) {
			u = user;
			return 1;
		} else {
			return 0;
		}
	}
	// �α׾ƿ�
	public void logout() {
		u = null;
	}

}
