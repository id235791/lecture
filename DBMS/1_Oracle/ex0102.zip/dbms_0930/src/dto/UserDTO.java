package dto;

public class UserDTO {
	private static int seq=25;
	private String name;
	private String birth;
	private String id;
	private String pw;
	private String address;
	private String phone;
	private String email;
	private String account;
	private int key;

	public static int getSeq() {
		return seq;
	}




	public UserDTO() {
		super();
	}
	
	
	public int getKey() {
		return key;
	}


	public void setKey(int key) {
		this.key = key;
	}


	public UserDTO(String name, String birth, String id, String pw, String address, String phone, String email,
			String account) {
		super();
		this.name = name;
		this.birth = birth;
		this.id = id;
		this.pw = pw;
		this.address = address;
		this.phone = phone;
		this.email = email;
		this.account = account;
		this.key=++seq;
	}

	
	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public String getBirth() {
		return birth;
	}


	public void setBirth(String birth) {
		this.birth = birth;
	}


	public String getId() {
		return id;
	}


	public void setId(String id) {
		this.id = id;
	}


	public String getPw() {
		return pw;
	}


	public void setPw(String pw) {
		this.pw = pw;
	}


	public String getAddress() {
		return address;
	}


	public void setAddress(String address) {
		this.address = address;
	}


	public String getPhone() {
		return phone;
	}


	public void setPhone(String phone) {
		this.phone = phone;
	}


	public String getEmail() {
		return email;
	}


	public static void setSeq(int seq) {
		UserDTO.seq = seq;
	}




	public void setEmail(String email) {
		this.email = email;
	}


	public String getAccount() {
		return account;
	}


	public void setAccount(String account) {
		this.account = account;
	}

	public String toString() {
		//ȸ����ȣ;;���̵�;;�н�����;;�̸�;;�������;;�޴�����ȣ;;�ּ�;;����;;�̸���
		String data =key+";;"+id + ";;"+pw+";;"+name + ";;"+birth+";;"+ phone + ";;" + address
				+ ";;" + account+";;"+email;
		return data;
	}
	
	@Override
	public boolean equals(Object obj) {
		if(obj instanceof UserDTO) {
			UserDTO user = (UserDTO) obj;
			if(user.key == this.key) {
				return true;
			}
		}
		return false;
	}
	@Override
	public int hashCode() {
		return this.key;
	}
}