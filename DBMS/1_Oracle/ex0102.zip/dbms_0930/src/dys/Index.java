package dys;

import java.io.IOException;

import dao.Login;

public class Index {
	public static void main(String[] args) throws IOException {
		new Login().loginStart();
	}
}
